Esta carpeta nos servira para guardar fragmentos de codigo reutilizables
