Pantallas que veran los usuarios
