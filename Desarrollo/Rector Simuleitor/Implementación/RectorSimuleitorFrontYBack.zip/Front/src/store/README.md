Aqui se manejara la logica de la aplicación
