function App() {
  return <>Juego</>;
}

export default App;
