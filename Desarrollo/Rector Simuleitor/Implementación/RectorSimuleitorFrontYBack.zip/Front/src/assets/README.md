Aqui se pondran las imagenes de fondo, personajes y demas iconos para la interfaz
