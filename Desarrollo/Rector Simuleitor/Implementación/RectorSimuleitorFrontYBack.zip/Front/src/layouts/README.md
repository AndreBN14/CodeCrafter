Plantilla para las paginas del juego
