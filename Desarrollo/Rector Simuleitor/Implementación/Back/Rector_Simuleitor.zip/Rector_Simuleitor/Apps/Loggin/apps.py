from django.apps import AppConfig


class LogginConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Apps.Loggin'
